from __future__ import annotations

from collections.abc import Mapping, Sequence
from enum import StrEnum

from typing_extensions import TypeAliasType

# https://docs.pydantic.dev/2.11/concepts/types/#named-recursive-types
JSON = TypeAliasType(
    "JSON", "None | bool | str | int | float | Sequence[JSON] | Mapping[str, JSON]"
)

# Type checkers only treat a TypedDict as Mapping[str, object], so generated
# Insert and Update TypedDicts need it to be accepted as a body.
RequestBody = TypeAliasType(
    "RequestBody", "JSON | Mapping[str, object] | Sequence[Mapping[str, object]]"
)

# A scalar value accepted by PostgREST filter operators. Used instead of ``Any``
# so the accepted types are explicit; values are still coerced to ``str`` when
# serialized into the query string.
FilterValue = str | int | float | bool


class CountMethod(StrEnum):
    exact = "exact"
    planned = "planned"
    estimated = "estimated"


class Filters(StrEnum):
    NOT = "not"
    EQ = "eq"
    NEQ = "neq"
    GT = "gt"
    GTE = "gte"
    LT = "lt"
    LTE = "lte"
    IS = "is"
    LIKE = "like"
    LIKE_ALL = "like(all)"
    LIKE_ANY = "like(any)"
    ILIKE = "ilike"
    ILIKE_ALL = "ilike(all)"
    ILIKE_ANY = "ilike(any)"
    FTS = "fts"
    PLFTS = "plfts"
    PHFTS = "phfts"
    WFTS = "wfts"
    IN = "in"
    CS = "cs"
    CD = "cd"
    OV = "ov"
    SL = "sl"
    SR = "sr"
    NXL = "nxl"
    NXR = "nxr"
    ADJ = "adj"


class RequestMethod(StrEnum):
    GET = "GET"
    POST = "POST"
    PATCH = "PATCH"
    PUT = "PUT"
    DELETE = "DELETE"
    HEAD = "HEAD"


class ReturnMethod(StrEnum):
    minimal = "minimal"
    representation = "representation"
